sap.ui.define([
	"Routing/controller/BaseController"
], function(BaseController) {
	"use strict";

	return BaseController.extend("Routing.controller.App", {

	});
});